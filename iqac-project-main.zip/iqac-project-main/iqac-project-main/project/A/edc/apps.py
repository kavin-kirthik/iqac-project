from django.apps import AppConfig


class EdcConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'edc'
