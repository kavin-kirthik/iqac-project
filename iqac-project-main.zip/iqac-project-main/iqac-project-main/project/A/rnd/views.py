from django.shortcuts import render
from core.helpers import *

def rnd_dash(request):
    context = set_config(request)
    return render(request, 'rnd/dash.html', context)

def rnd_pp(request):
    context = set_config(request)
    return render(request, 'rnd/paperpublication.html', context)
    
def rnd_rod(request):
    context = set_config(request)
    return render(request, 'rnd/researchod.html', context)
    
def rnd_pat(request):
    context = set_config(request)
    return render(request, 'rnd/patents.html', context)
    
def rnd_ma(request):
    context = set_config(request)
    return render(request, 'rnd/momatr.html', context)

def rnd_rdd(request):
    context = set_config(request)
    return render(request, 'rnd/rddetails.html', context)

def rnd_feed(request):
    context = set_config(request)
    return render(request, 'rnd/feedback.html', context)


def rnd_pro(request):
    context = set_config(request)
    return render(request, 'rnd/proposal.html', context)

def rnd_doc(request):
    context = set_config(request)
    return render(request, 'rnd/doctorate.html', context)

def rnd_sch(request):
    context = set_config(request)
    return render(request, 'rnd/scholar.html', context)

def rnd_staff(request):
    context = set_config(request)
    return render(request, 'rnd/staff.html', context)


def rnd_approd(request):
    context = set_config(request)
    return render(request, 'rnd/approd.html', context)

def rnd_apppaper(request):
    context = set_config(request)
    return render(request, 'rnd/apppaper.html', context)

def rnd_apppropose(request):
    context = set_config(request)
    return render(request, 'rnd/apppropose.html', context)

def rnd_apppatent(request):
    context = set_config(request)
    return render(request, 'rnd/apppatent.html', context)

def rnd_member(request):
    context = set_config(request)
    return render(request, 'rnd/newmem.html', context)

def rnd_sd(request):
    context = set_config(request)
    return render(request, 'rnd/studentdash.html', context)