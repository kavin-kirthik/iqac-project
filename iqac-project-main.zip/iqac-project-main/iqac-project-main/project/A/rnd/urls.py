from django.urls import path
from .views import *;

urlpatterns = [
    path("",rnd_dash,name='rnd_dash'),
    path("pp",rnd_pp,name='rnd_pp'),
    path("rod",rnd_rod,name='rnd_rod'),
    path("pat",rnd_pat,name='rnd_pat'),
    path("ma",rnd_ma,name='rnd_ma'),
    path("rdd",rnd_rdd,name='rnd_rdd'),
    path("feed",rnd_feed,name="rnd_feed"),
    path("pro",rnd_pro,name="rnd_pro"),
    path("doc",rnd_doc,name="rnd_doc"),
    path("sch",rnd_sch,name="rnd_sch"),
    path("staff",rnd_staff,name="rnd_staff"),
    
    path("approd",rnd_approd,name="rnd_approd"),
    path("apat",rnd_apppatent,name="rnd_apppatent"),
    path("apaper",rnd_apppaper,name="rnd_apppaper"),
    path("apro",rnd_apppropose,name="rnd_apppropose"),
    path("new",rnd_member,name="rnd_member"),
    path("studash",rnd_sd,name='rnd_sd')
]
