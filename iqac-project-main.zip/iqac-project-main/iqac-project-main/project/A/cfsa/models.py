from django.db import models


class BonafideRequest(models.Model):
    student_name = models.CharField(max_length=100)
    reason = models.TextField()
    approved = models.BooleanField(default=False)
   
    def __str__(self):
        return self.student_name

class HackathonRegistration(models.Model):
    student_name = models.CharField(max_length=100)
    project_name = models.CharField(max_length=100)
    registered_at = models.DateTimeField(auto_now_add=True)
   
    def __str__(self):
        return self.student_name

class ODRequest(models.Model):
    student_name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    approved = models.BooleanField(default=False)
   
    def __str__(self):
        return self.student_name

class UBAParticipation(models.Model):
    student_name = models.CharField(max_length=100)
    project_name = models.CharField(max_length=100)
   
    def __str__(self):
        return self.student_name
# Model for Attendance Logs
class AttendanceLog(models.Model):
    student_name = models.CharField(max_length=100)
    date = models.DateField()
    status = models.CharField(max_length=20)

# Model for Circulars
class Circular(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
# Model for Event Records

# Model for Event Reports
class EventReport(models.Model):
    event_name = models.CharField(max_length=100)
    report = models.TextField()

# Model for Service Requests
class ServiceRequest(models.Model):
    request_type = models.CharField(max_length=100)
    description = models.TextField()

# Model for Databases
class Database(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

# Model for Feedbacks and Reviews
class FeedbackReview(models.Model):
    user_name = models.CharField(max_length=100)
    feedback = models.TextField()

class mom_atr(models.Model):
    mom=models.CharField(max_length=200)

class isc(models.Model):
    isc=models.CharField(max_length=100)

    
