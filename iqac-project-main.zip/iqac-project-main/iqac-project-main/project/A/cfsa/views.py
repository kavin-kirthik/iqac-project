from django.shortcuts import render
from core.models import OD, Staff, Student 
from core.helpers import set_config

from .models import BonafideRequest, HackathonRegistration, ODRequest, UBAParticipation
def cfsa_dash(request):
    context = set_config(request)
    return render(request,'cfsa/dash.html',context)

def bonafide_request(request):
    if request.method == 'POST':
        student_name = request.POST.get('student_name')
        reason = request.POST.get('reason')

        bonafide_request = BonafideRequest(student_name=student_name, reason=reason)
        bonafide_request.save()

        return render(request, 'success.html')
    else:
        return render(request, 'cfsa/bonafide_request.html')

def hackathon_registration(request):
    if request.method == 'POST':
        student_name = request.POST.get('student_name')
        project_name = request.POST.get('project_name')

        hackathon_registration = HackathonRegistration(student_name=student_name, project_name=project_name)
        hackathon_registration.save()

        return render(request, 'success.html')
    else:
        return render(request, 'cfsa/hackathon_registration.html')

def od_request(request):
    if request.method == 'POST':
        student_name = request.POST.get('student_name')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        reason = request.POST.get('reason')

        od_request = ODRequest(student_name=student_name, start_date=start_date, end_date=end_date, reason=reason)
        od_request.save()
        context = {}
        context = set_config(request)
        context['odstudent']=OD.objects.filter()
        return render(request,'cfsa/od_request.html',context)
    else:
        context = {}
        context = set_config(request)
        context['odstudent']=OD.objects.filter()
        return render(request,'cfsa/od_request.html',context)

def uba_participation(request):
    if request.method == 'POST':
        student_name = request.POST.get('student_name')
        project_name = request.POST.get('project_name')

        uba_participation = UBAParticipation(student_name=student_name, project_name=project_name)
        uba_participation.save()

        return render(request, 'success.html')
    else:
        return render(request, 'cfsa/uba_participation.html')
# Attendance Logs
def attendance_logs(request):
    return render(request, 'cfsa/attendance_logs.html')

# Circulars
def circulars(request):
    return render(request, 'cfsa/circulars.html')

# Event Reports
def event_reports(request):
    return render(request, 'cfsa/event_reports.html')

# Event Records


# Service Requests
def service_requests(request):
    return render(request, 'cfsa/service_requests.html')

# Databases
def databases(request):
    return render(request, 'cfsa/databases.html')

# Feedbacks and Reviews
def feedbacks_reviews(request):
    return render(request, 'cfsa/feedbacks_reviews.html')

def mom_atr(request):
    return render(request,'cfsa/mom_atr.html')

def isc(request):
    return render(request,'cfsa/isc.html',)

def student_database(request):
    context={}
    context['sdb']=Student.objects.filter()
    return render(request, 'cfsa/student_database.html',context)

def staff_database(request):
    context={}
    context['staffdb']=Staff.objects.filter()
    return render(request, 'cfsa/staff_database.html',context)
