from django.urls import path
from .views import *

urlpatterns = [
    path("",cfsa_dash,name='cfsa_dash')
    
]

urlpatterns+=[ path('bonafide/', bonafide_request, name='bonafide_request'),
    path('hackathon/',hackathon_registration, name='hackathon_registration'),
    path('od/', od_request, name='od_request'),
    path('uba/', uba_participation, name='uba_participation'),
    path('attendance_logs/', attendance_logs, name='attendance_logs'),
    path('circulars/', circulars, name='circulars'),
    path('event_reports/', event_reports, name='event_reports'),
    path('service_requests/', service_requests, name='service_requests'),
    path('databases/',databases, name='databases'),
    path('feedbacks_reviews/',feedbacks_reviews, name='feedbacks_reviews'),
    path('mom_atr/', mom_atr,name='mom_atr'),
    path('isc/',isc, name='isc'),
    path('student_database/',student_database, name='student_database'),
    path('staff_database/',staff_database, name='staff_database'),    ]
    