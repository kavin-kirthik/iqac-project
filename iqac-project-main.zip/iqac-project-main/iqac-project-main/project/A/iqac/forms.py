# forms.py
from django import forms

class TextInputForm(forms.Form):
    input_text = forms.CharField(label='Enter Text', max_length=100)
