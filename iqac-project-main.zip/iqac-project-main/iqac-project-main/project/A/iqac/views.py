from django.shortcuts import render
from core.helpers import *
from core.models import Student
from core.constants import *
from core.models import *
from iqac.models import *
from .forms import TextInputForm
# Create your views here.
def iqac_dash(request):
    context=set_config(request)
    return render(request,'iqac/dash.html',context)
def iqac_Acadamic_view(request):
    context =set_config(request)
    context['students_aca'] = []
    for i in Student_Details.objects.all():
        context['students_aca'].append([i,PLACEMENT[i.Placement][1],TRANSPORT[i.transport][1]])
    return render(request,'iqac/Acadamic.html',context)

def iqac_Library_view(request):
    context=set_config(request)
    
    context['libbook'] = Book.objects.filter()

    return render(request,'iqac/Library.html',context)
def iqac_Administration_view(request):
    context=set_config(request)
    return render(request,'iqac/Administration.html',context)
def iqac_PlacementTraining_view(request):
    context=set_config(request)
    context['s_students'] = Student_Details.objects.filter(Placement=2)
    context['non_students'] = Student_Details.objects.filter(Placement=0)
    context['normal_students'] = Student_Details.objects.filter(Placement=1)

    return render(request,'iqac/Placement & Training.html',context)

def iqac_Placement_Students_view(request):
    context=set_config(request)
    context['s_students'] = Student_Details.objects.all()

    return render(request,'iqac/Placement_Students.html',context)

def iqac_Placed_Students_view(request):
    context=set_config(request)
    context['s_students'] = Student_Details.objects.filter(is_placed="True")
    
    return render(request,'iqac/Placed_Students.html',context)
#Hostel


def iqac_Hostel_view(request):
    
    context=set_config(request)

    context['bus_students'] = Student_Details.objects.filter(transport=2)
    context['day_students'] = Student_Details.objects.filter(transport=0)
    context['hos_students'] = Student_Details.objects.filter(transport=1)


    return render(request,'iqac/Hostel.html',context)
#Transport
def iqac_Transport_view(request):
    #contect
    context=set_config(request)

    context['bus_details'] = Bus.objects.all()

    print(context)

    return render(request,'iqac/Transport.html',context)


#placement

#Studentregistration

def iqac_Studentregistration_view(request):
    context=set_config(request)
    return render(request,'iqac/Studentregistration.html',context)

def bonafide_request(request):
    if request.method == 'POST':
        student_name = request.POST.get('student_name')
        reason = request.POST.get('reason')

        bonafide_request = BonafideRequest(student_name=student_name, reason=reason)
        bonafide_request.save()

        return render(request, 'success.html')
    else:
        return render(request, 'cfsa/bonafide_request.html')

def iqac_Activity_view(request):
    return render(request,"iqac/Activity.html")

def iqac_Pap_view(request):
    return render(request,"iqac/pap.html")

def iqac_Std_view(request):
    return render(request,"iqac/std.html")
def iqac_meet_view(request):
    return render(request,"iqac/meetings.html")

#search bar

