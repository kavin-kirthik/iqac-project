
from django.db import models
from core.models import *
from django.contrib.auth.models import User
from django.urls import reverse
from core.constants import *
from django.core.validators import MaxValueValidator

class Bus(models.Model):
    bno = models.CharField(max_length=255)
    Driver_name = models.CharField(max_length=255)
    rootname = models.CharField(max_length=100)
    no_stu = models.PositiveIntegerField(blank=True,null=True)
    

    def __str__(self):
        return f"{self.bno}"


class Book(models.Model):
    uid = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    aurthor = models.CharField(max_length=100)
    is_avilable = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name}"

class Purchase(models.Model):
    #uid = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    aurthor = models.CharField(max_length=100)
   # is_avilable = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name}"





class IQAC_CENTER(models.Model):
    base = models.ForeignKey(Centers,unique=True,on_delete=models.CASCADE,related_name='base',blank=True)
    # Library
    books = models.ManyToManyField(Book,blank=True)
    lib_staff = models.ManyToManyField(Staff,related_name='lib_staffs',blank=True)


class Student_Details(models.Model):
    student = models.ForeignKey(Student,on_delete=models.CASCADE,related_name='student_details')
    #busno = models.ForeignKey(Bus,on_delete=models.CASCADE,related_name='student_details')
    transport = models.PositiveIntegerField(choices=TRANSPORT,default=0)
    Placement = models.PositiveIntegerField(choices=PLACEMENT,default=0)
    cgpa = models.CharField(max_length=50,blank=True,null=True)
    name = models.CharField(max_length=50,blank=True,null=True)
    year = models.PositiveIntegerField(choices=YEAR,default=1,null=True)
    
    #    pt1 = models.PositiveIntegerField(validators=[MaxValueValidator(150, message="Age must be 150 or less.")] )
    pt1 = models.PositiveIntegerField(blank=True,null=True )
    ssa1 = models.PositiveIntegerField(blank=True,null=True)

    ciat1 = models.PositiveIntegerField(blank=True,null=True)
    fa1 = models.PositiveIntegerField(blank=True,null=True)
    
    pt2 = models.PositiveIntegerField(blank=True,null=True)
    ssa2 = models.PositiveIntegerField(blank=True,null=True)
    
    ciat2 = models.PositiveIntegerField(blank=True,null=True)
    fa2 = models.PositiveIntegerField(blank=True,null=True)
   # nocompanies = models.PositiveIntegerField(blank=True,null=True)
    no_companies = models.PositiveIntegerField(blank=True,null=True)
    is_placed = models.BooleanField(default=False)
    company_name = models.CharField(max_length=50,blank=True,null=True)
   
    def __str__(self):
        return f"{self.student.name}"
#search

class YourModel(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name

