from django.contrib import admin
from .models import *
from import_export.admin import ImportExportModelAdmin


# class LibraryAdmin(ImportExportModelAdmin):
#     list_display = ('name',)
#     search_fields = ("name",)
admin.site.register(Purchase)
admin.site.register(Bus)
admin.site.register(Book)
admin.site.register(Student_Details)
admin.site.register(IQAC_CENTER)
