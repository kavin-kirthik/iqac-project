from django.urls import path
from.views import *

urlpatterns = [
    path("",iqac_dash,name='iqac_dash'),
]
urlpatterns += [
    path("Acadamic/",iqac_Acadamic_view,name='iqac_Acadamic_view'),
    path("Library/",iqac_Library_view,name='iqac_Library_view'),
    path("Administration/",iqac_Administration_view,name='iqac_Administration_view'),
    path("PlacementTraining/",iqac_PlacementTraining_view,name='iqac_PlacementTraining_view'),
    #Hostel
    path("Hostel/",iqac_Hostel_view,name='iqac_Hostel_view'),
    #iqac_Transport_view
    path("Transport/",iqac_Transport_view,name='iqac_Transport_view'),
    path("Activity/",iqac_Activity_view,name="iqac_Activity_view"),
    path("Pap/",iqac_Pap_view,name="iqac_Pap_view"),
    path("Std/",iqac_Std_view,name="iqac_Std_view"),
    path("meetings/",iqac_meet_view,name="iqac_meet_view"),
        #Placement Students
    path("Placement_Students/",iqac_Placement_Students_view,name='iqac_Placement_Students_view'), 
    #Placed Students
    path("Placed_Students/",iqac_Placed_Students_view,name='iqac_Placed_Students_view'),   
    #Studentregistration
    #search
 #   path('input/', input_text, name='input_text'),
#    path('display/<str:input_text>/', display_text, name='display_text'),   
]

# urls.py
#from .views import input_text, display_text

