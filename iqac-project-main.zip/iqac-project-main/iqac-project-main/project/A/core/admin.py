from django.contrib import admin

from .models import *

from import_export.admin import ImportExportModelAdmin


class StudentsAdmin(ImportExportModelAdmin):
    list_display = ('name', 'roll', 'department','year')
    search_fields = ("roll", "name", "department",'year')


class StaffAdmin(ImportExportModelAdmin):
    list_display = ('name', 'user', 'department','position')
    search_fields = ("roll", "user", "department",'name')

class ODAdmin(ImportExportModelAdmin):
    list_display = ['user','sub','start','end','Hstatus']
    search_fields = ['user','sub','start','end','Hstatus']
    
class LEAVEAdmin(ImportExportModelAdmin):
    list_display = ['user','sub','start','end','Hstatus']
    search_fields = ['user','sub','start','end','Hstatus']

    
class GATEPASSAdmin(ImportExportModelAdmin):
    list_display = ['user','sub','start','end','Hstatus']
    search_fields = ['user','sub','start','end','Hstatus']


class HODAdmin(ImportExportModelAdmin):
    list_display = ['user','department']
    search_fields = ['user','department',]
        
class StaffRatingAdmin(ImportExportModelAdmin):
    list_display = ['staff','student','created']
    search_fields = ['staff','student','created']

class RatingQuestionsAdmin(ImportExportModelAdmin):
    list_display = ['user','ques','created']
    search_fields = ['user','ques','created']
    
class IndividualStaffRatingAdmin(ImportExportModelAdmin):
    list_display = ['staff','student','created']
    search_fields = ['staff','student','created']

class SpotFeedbackAdmin(ImportExportModelAdmin):
    list_display = ['user','staff','section','year','created']
    search_fields = ['user','staff','section','year','created']


class NotificationAdmin(ImportExportModelAdmin):
    list_display = ['sender','reciver','msg','created']
    search_fields = ['sender','reciver','msg','created']



admin.site.register(Student,StudentsAdmin)
admin.site.register(Staff,StaffAdmin)
admin.site.register(OD,ODAdmin)
admin.site.register(LEAVE,LEAVEAdmin)
admin.site.register(GATEPASS,GATEPASSAdmin)
admin.site.register(HOD,HODAdmin)
admin.site.register(StaffRating,StaffRatingAdmin)

admin.site.register(RatingQuestions,RatingQuestionsAdmin)
admin.site.register(IndividualStaffRating,IndividualStaffRatingAdmin)
admin.site.register(SpotFeedback,SpotFeedbackAdmin)

admin.site.register(Notification,NotificationAdmin)

admin.site.register(Centers)