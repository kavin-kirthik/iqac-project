from django.http import JsonResponse
from .models import *
import json


def get_notification(request):
    data = {
        "obj":"",
        "error":""
    }
    if request.method == 'GET':
        notifications = Notification.objects.filter(reciver=request.user)
        return JsonResponse(data)
    else:
        data["error"] = "In Valid Request"
        return JsonResponse(data)
        
