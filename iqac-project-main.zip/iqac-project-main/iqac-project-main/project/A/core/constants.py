DEPT = (
    ("001","B-Tech Artificial Intelliegnence and Machine Learninig"),
    ("243","B-Tech Artificial Intelliegnence and Data Science"),
    ("104","BE Computer Science Engineering"),
    ("","BE Civil Engineering"),
    ("114","BE Mechanical Engineering"),
    ("106","BE Electrical and Communication Engineering"),
)
SDEPT = (
    (0,"B-Tech Artificial Intelliegnence"),
    (1,"BE Computer Science and Engineering"),
    (2,"BE Electrical and Communication Engineering"),
    (4,"None"),
    (3,"BE Computer Science Engineering"),
    (5,"BE Civil Engineering"),
    (6,"BE Mechanical Engineering"),
    (7,"BE Electrical and Communication Engineering"),
)
POS = (
    (0,"Head of the Department"),
    (1,"Assistant Head of the Department"),
    (3,"Lecturer"),
    (4,"Centre for Students Affairs"),
    (5,"Centre For Students Welfare"),
    (6,"Centre for Placement And Training"),
    (7,"Centre for Ranking And Accredidations"),
    (8,"Centre for Research And Development"),
    (9,"Centre for Entrepreneurship Development Cell"),
    (10,"Centre for Internal Quality Assurance Cell"),
    (11,"Centre for Controller of Examination"),
    (12,"Principal")
)

CENTERS = (
    (0,"Centre for Students Affairs"),
    (1,"Centre For Students Welfare"),
    (2,"Centre for Placement And Training"),
    (3,"Centre for Ranking And Accredidations"),
    (4,"Centre for Research And Development"),
    (5,"Centre for Entrepreneurship Development Cell"),
    (6,"Centre for Internal Quality Assurance Cell"),
    (7,"Centre for Controller of Examination"),
    (8,"none")
)

SEM = (
    (1,"SEM - 1"),
    (2,"SEM - 2"),
    (3,"SEM - 3"),
    (4,"SEM - 4"),
    (5,"SEM - 5"),
    (6,"SEM - 6"),
    (7,"SEM - 7"),
    (8,"SEM - 8"),
)

YEAR = (
    (1,"I"),
    (2,"II"),
    (3,"III"),
    (4,"IV"),
    )

BLOOD_GROUP = (
    (1,"A +"),
    (2,"AB +"),
    (3,"A1 +"),
    (4,"O +"),
    (5,"AB -"),
    (6,"O -"),
    (7,"A -"),
    (8,"B +"),
    (9,"A1 -"),
    (10,"B -")
    )

STATUS = (
    ("Pending",'Pending'),
    ("Approved",'Approved'),
    ("Rejected",'Rejected'),
)

SECTION = (
    (0,'Artificial Intelliegnence and Machine Learninig'),
    (1,'Artificial Intelliegnence and Data Science'),
    (2,'A'),
    (3,'B'),
    (4,'C'),
)

TRANSPORT = (
    (0,"Day Scholler"),
    (1,"Hosteler"),
    (2,"College Buss"),
)

PLACEMENT = (
    (0,"NON"),
    (1,"NORMAL"),
    (2,"Special"),
)

YEAR=(
    
    (1,"1st"),
    (2,"2nd"),
    (3,"3rd"),
    (4,"4rd"),
)

